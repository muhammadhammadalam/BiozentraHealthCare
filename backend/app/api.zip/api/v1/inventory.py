from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.inventory import Inventory
from app.schemas.inventory import InventoryCreate, InventoryResponse

router = APIRouter()

@router.post("/", response_model=InventoryResponse)
def add_inventory(payload: InventoryCreate, db: Session = Depends(get_db)):
    try:
        entry = Inventory(**payload.dict())
        db.add(entry)
        db.commit()
        db.refresh(entry)
        return entry
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to add inventory")

@router.put("/{inventory_id}", response_model=InventoryResponse)
def update_inventory(
    inventory_id: int,
    payload: InventoryCreate,
    db: Session = Depends(get_db)
):
    entry = db.query(Inventory).filter(Inventory.id == inventory_id).first()

    if not entry:
        raise HTTPException(status_code=404, detail="Inventory record not found")

    try:
        entry.product_id = payload.product_id
        entry.quantity = payload.quantity
        db.commit()
        db.refresh(entry)
        return entry
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update inventory")

@router.delete("/{inventory_id}")
def delete_inventory(inventory_id: int, db: Session = Depends(get_db)):
    entry = db.query(Inventory).filter(Inventory.id == inventory_id).first()

    if not entry:
        raise HTTPException(status_code=404, detail="Inventory record not found")

    try:
        db.delete(entry)
        db.commit()
        return {"message": "Inventory record deleted"}
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete inventory")
