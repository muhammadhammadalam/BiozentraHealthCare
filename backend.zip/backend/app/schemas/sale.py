from pydantic import BaseModel
from datetime import datetime

class SaleCreate(BaseModel):
    product_id: int
    quantity: int
    unit_price: float

class SaleUpdate(BaseModel):
    quantity: int

class SaleResponse(SaleCreate):
    id: int
    timestamp: datetime

    class Config:
        from_attributes = True
