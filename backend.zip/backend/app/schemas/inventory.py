from pydantic import BaseModel
from typing import Optional

class InventoryCreate(BaseModel):
    product_id: int
    quantity: int

class InventoryUpdate(BaseModel):
    quantity: int

class InventoryResponse(InventoryCreate):
    id: int

    class Config:
        from_attributes = True
