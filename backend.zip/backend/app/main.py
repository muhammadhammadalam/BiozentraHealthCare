from fastapi import FastAPI
from app.core.database import Base, engine
from app.api.v1 import products, inventory, sales

app = FastAPI(title="Biozentra Healthcare Backend")

Base.metadata.create_all(bind=engine)

app.include_router(products.router, prefix="/api/v1/products", tags=["Products"])
app.include_router(inventory.router, prefix="/api/v1/inventory", tags=["Inventory"])
app.include_router(sales.router, prefix="/api/v1/sales", tags=["Sales"])
