from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from app.core.database import get_db
from app.models.sale import Sale
from app.models.inventory import Inventory
from app.schemas.sale import SaleCreate, SaleResponse

router = APIRouter(prefix="/sales", tags=["Sales"])


@router.post("/", response_model=SaleResponse)
def record_sale(payload: SaleCreate, db: Session = Depends(get_db)):
    try:
        inventory = (
            db.query(Inventory)
            .filter(Inventory.product_id == payload.product_id)
            .with_for_update()
            .first()
        )

        if inventory is None:
            raise HTTPException(status_code=404, detail="Inventory record not found")

        if inventory.quantity < payload.quantity:
            raise HTTPException(status_code=400, detail="Insufficient stock")

        inventory.quantity = inventory.quantity - payload.quantity

        sale = Sale(
            product_id=payload.product_id,
            quantity=payload.quantity,
            unit_price=payload.unit_price,
            total_price=payload.quantity * payload.unit_price
        )

        db.add(sale)
        db.commit()
        db.refresh(sale)

        return sale

    except HTTPException:
        db.rollback()
        raise

    except SQLAlchemyError:
        db.rollback()
        raise HTTPException(status_code=500, detail="Transaction failed")
