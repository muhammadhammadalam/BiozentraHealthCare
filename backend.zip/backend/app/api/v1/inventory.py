from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.inventory import Inventory
from app.schemas.inventory import InventoryCreate, InventoryResponse

router = APIRouter(prefix="/inventory", tags=["Inventory"])

@router.post("/", response_model=InventoryResponse)
def create_inventory(payload: InventoryCreate, db: Session = Depends(get_db)):
    try:
        inventory = Inventory(**payload.dict())
        db.add(inventory)
        db.commit()
        db.refresh(inventory)
        return inventory
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Inventory creation failed")

@router.get("/", response_model=list[InventoryResponse])
def list_inventory(db: Session = Depends(get_db)):
    return db.query(Inventory).all()

@router.put("/{inventory_id}", response_model=InventoryResponse)
def update_inventory(
    inventory_id: int,
    payload: InventoryCreate,
    db: Session = Depends(get_db)
):
    inventory = db.query(Inventory).filter(Inventory.id == inventory_id).first()

    if not inventory:
        raise HTTPException(status_code=404, detail="Inventory not found")

    try:
        for key, value in payload.dict().items():
            setattr(inventory, key, value)
        db.commit()
        db.refresh(inventory)
        return inventory
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Inventory update failed")

@router.delete("/{inventory_id}")
def delete_inventory(inventory_id: int, db: Session = Depends(get_db)):
    inventory = db.query(Inventory).filter(Inventory.id == inventory_id).first()

    if not inventory:
        raise HTTPException(status_code=404, detail="Inventory not found")

    try:
        db.delete(inventory)
        db.commit()
        return {"message": "Inventory deleted"}
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Inventory deletion failed")
